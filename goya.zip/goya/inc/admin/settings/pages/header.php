<h1><?php esc_html_e('Goya', 'goya'); ?><span class="version"><?php esc_html_e('Version:', 'goya'); ?> <?php echo GOYA_THEME_VERSION; ?></span></h1>
<p class="about-text welcome-text"><?php esc_html_e('Congratulations for your excellent taste in WordPress themes. Welcome to Goya!', 'goya'); ?></p>
<?php include 'tabs.php'; ?>