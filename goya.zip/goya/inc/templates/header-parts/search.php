<?php
/**
 * Template part for displaying the search icon
 *
 * @package Goya
 */
?>

<?php do_action( 'goya_quick_search_button' ); ?>
